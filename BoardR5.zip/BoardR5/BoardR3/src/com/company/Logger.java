package com.company;

public interface Logger {
    void log(String value);
}
