DROP DATABASE IF EXISTS leaf_library;
CREATE DATABASE leaf_library;
USE leaf_library;

CREATE TABLE authors (
        author_id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(100) NOT NULL,
        last_name  VARCHAR(100) NOT NULL
);

CREATE TABLE books (
        book_id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        isbn VARCHAR(20) UNIQUE NOT NULL,
        genre VARCHAR(100),
        published_year YEAR
);

CREATE TABLE book_authors (
        book_id INT NOT NULL,
        author_id INT NOT NULL,
        PRIMARY KEY (book_id, author_id),
        FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE,
        FOREIGN KEY (author_id) REFERENCES authors(author_id) ON DELETE CASCADE
);

CREATE TABLE copies (
        copy_id INT AUTO_INCREMENT PRIMARY KEY,
        book_id INT NOT NULL,
        shelf_code VARCHAR(50) NOT NULL,
        is_available BOOLEAN DEFAULT TRUE,
        FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE
);

CREATE TABLE members (
        member_id INT AUTO_INCREMENT PRIMARY KEY,
        full_name VARCHAR(200) NOT NULL,
        email VARCHAR(150) UNIQUE NOT NULL,
        join_date DATE NOT NULL DEFAULT (CURRENT_DATE)
);

CREATE TABLE loans (
        loan_id INT AUTO_INCREMENT PRIMARY KEY,
        copy_id INT NOT NULL,
        member_id INT NOT NULL,
        loan_date DATE NOT NULL DEFAULT (CURRENT_DATE),
        due_date DATE NOT NULL DEFAULT (DATE_ADD(CURRENT_DATE, INTERVAL 14 DAY)),
        return_date DATE,
        FOREIGN KEY (copy_id) REFERENCES copies(copy_id),
        FOREIGN KEY (member_id) REFERENCES members(member_id)
);
DELIMITER //
CREATE TRIGGER check_max_loans
    BEFORE INSERT ON loans
    FOR EACH ROW
BEGIN
    DECLARE active_loans INT;
    SELECT COUNT(*) INTO active_loans
    FROM loans
    WHERE member_id = NEW.member_id AND return_date IS NULL;

    IF active_loans >= 5 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Member cannot borrow more than 5 books at a time';
    END IF;
END;
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER check_copy_availability
    BEFORE INSERT ON loans
    FOR EACH ROW
BEGIN
    DECLARE available BOOLEAN;
    SELECT is_available INTO available FROM copies WHERE copy_id = NEW.copy_id;

    IF available = FALSE THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Copy is already loaned out';
    ELSE
        UPDATE copies SET is_available = FALSE WHERE copy_id = NEW.copy_id;
    END IF;
END;
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER return_copy
    AFTER UPDATE ON loans
    FOR EACH ROW
BEGIN
    IF NEW.return_date IS NOT NULL THEN
        UPDATE copies SET is_available = TRUE WHERE copy_id = NEW.copy_id;
    END IF;
END;
//
DELIMITER ;

SELECT loan_id, member_id,
       GREATEST(DATEDIFF(return_date, due_date), 0) * 0.50 AS fine
FROM loans
WHERE return_date IS NOT NULL;
USE leaf_library;

-- ==============================
-- AUTHORS (20)
-- ==============================
-- ==============================
-- DATABASE
-- ==============================
DROP DATABASE IF EXISTS leaf_library;
CREATE DATABASE leaf_library;
USE leaf_library;

-- ==============================
-- TABLES
-- ==============================
CREATE TABLE authors (
                         author_id INT AUTO_INCREMENT PRIMARY KEY,
                         first_name VARCHAR(100) NOT NULL,
                         last_name VARCHAR(100) NOT NULL
);

CREATE TABLE books (
                       book_id INT AUTO_INCREMENT PRIMARY KEY,
                       title VARCHAR(255) NOT NULL,
                       isbn VARCHAR(20) UNIQUE NOT NULL,
                       genre VARCHAR(100),
                       published_year YEAR
);

CREATE TABLE book_authors (
                              book_id INT NOT NULL,
                              author_id INT NOT NULL,
                              PRIMARY KEY (book_id, author_id),
                              FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE,
                              FOREIGN KEY (author_id) REFERENCES authors(author_id) ON DELETE CASCADE
);

CREATE TABLE copies (
                        copy_id INT AUTO_INCREMENT PRIMARY KEY,
                        book_id INT NOT NULL,
                        shelf_code VARCHAR(50) NOT NULL,
                        is_available BOOLEAN DEFAULT TRUE,
                        FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE
);

CREATE TABLE members (
                         member_id INT AUTO_INCREMENT PRIMARY KEY,
                         full_name VARCHAR(200) NOT NULL,
                         email VARCHAR(150) UNIQUE NOT NULL,
                         join_date DATE NOT NULL DEFAULT (CURRENT_DATE)
);

CREATE TABLE loans (
                       loan_id INT AUTO_INCREMENT PRIMARY KEY,
                       copy_id INT NOT NULL,
                       member_id INT NOT NULL,
                       loan_date DATE NOT NULL DEFAULT (CURRENT_DATE),
                       due_date DATE NOT NULL DEFAULT (DATE_ADD(CURRENT_DATE, INTERVAL 14 DAY)),
                       return_date DATE,
                       FOREIGN KEY (copy_id) REFERENCES copies(copy_id),
                       FOREIGN KEY (member_id) REFERENCES members(member_id)
);

-- ==============================
-- SAMPLE DATA
-- ==============================
-- Authors
INSERT INTO authors (first_name, last_name) VALUES
                                                ('George', 'Orwell'),
                                                ('J.K.', 'Rowling'),
                                                ('Jane', 'Austen');

-- Books
INSERT INTO books (title, isbn, genre, published_year) VALUES
                                                           ('1984', '9780451524935', 'Dystopian', 1949),
                                                           ('Harry Potter and the Philosopher''s Stone', '9780747532699', 'Fantasy', 1997),
                                                           ('Pride and Prejudice', '9780141439518', 'Romance', 1931);

-- Book-Authors
INSERT INTO book_authors (book_id, author_id) VALUES
                                                  (1, 1),
                                                  (2, 2),
                                                  (3, 3);

-- Copies
INSERT INTO copies (book_id, shelf_code) VALUES
                                             (1, 'A-101'), (1, 'A-102'),
                                             (2, 'B-201'),
                                             (3, 'C-301');

-- Members
INSERT INTO members (full_name, email, join_date) VALUES
                                                      ('Alice Johnson', 'alice@example.com', '2025-01-15'),
                                                      ('Bob Smith', 'bob@example.com', '2025-01-20'),
                                                      ('Charlie Brown', 'charlie@example.com', '2025-01-25');

-- Loans
INSERT INTO loans (copy_id, member_id, loan_date, due_date, return_date) VALUES
                                                                             (1, 1, '2025-09-01', '2025-09-15', '2025-09-14'), -- returned on time
                                                                             (2, 2, '2025-09-05', '2025-09-19', NULL),          -- active
                                                                             (3, 3, '2025-09-07', '2025-09-21', NULL);          -- active
-- Queries--
#1
SELECT b.title AS book_title,CONCAT(a.first_name,' ',a.last_name)AS author FROM books AS b
JOIN book_authors ba on b.book_id = ba.book_id
JOIN authors a on ba.author_id = a.author_id;
#2
SELECT c.copy_id, b.title,
       CASE
           WHEN l.return_date IS NULL AND CURDATE() <= l.due_date THEN 'On loan'
           WHEN l.return_date IS NULL AND CURDATE() > l.due_date THEN 'Overdue'
           ELSE 'Available'
           END AS availability
FROM copies c
         JOIN books b ON c.book_id = b.book_id
         LEFT JOIN loans l ON c.copy_id = l.copy_id
WHERE b.title = '1984';
#3
SELECT b.title, CONCAT(a.first_name,' ',a.last_name)AS author from books AS b
JOIN book_authors ba on b.book_id = ba.book_id
JOIN authors a on ba.author_id = a.author_id
WHERE b.title LIKE '%19%' OR a.last_name= 'Rowling';
#4
SELECT
    m.full_name, b.title, c.copy_id, l.loan_date,l.due_date FROM members as m
JOIN loans l on m.member_id = l.member_id
JOIN copies c on l.copy_id = c.copy_id
JOIN books b on c.book_id = b.book_id
WHERE l.return_date IS NULL;
#5
SELECT
    m.full_name, b.title, c.copy_id, l.loan_date,l.due_date FROM members as m
JOIN loans l on m.member_id = l.member_id
JOIN copies c on l.copy_id = c.copy_id
JOIN books b on c.book_id = b.book_id
WHERE l.return_date > l.due_date;
#6
SELECT b.title,COUNT(l.loan_id)AS total_loan_count FROM books AS b
JOIN copies c on b.book_id = c.book_id
JOIN loans l on c.copy_id = l.copy_id
        GROUP BY b.title
        ORDER BY total_loan_count DESC
        LIMIT 3;
#7
SELECT DATE_FORMAT(loan_date, '%Y-%m') AS month, COUNT(*) AS loan_count
FROM loans
WHERE loan_date >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
GROUP BY DATE_FORMAT(loan_date, '%Y-%m')
ORDER BY month;
#8
SELECT m.full_name AS member
FROM members m
         JOIN loans l ON m.member_id = l.member_id
WHERE l.return_date IS NULL
GROUP BY m.member_id
HAVING COUNT(*) = 5;
#9
SELECT m.full_name AS member
FROM members m
         JOIN loans l ON m.member_id = l.member_id
WHERE l.return_date IS NOT NULL
GROUP BY m.member_id
HAVING AVG(DATEDIFF(l.return_date, l.due_date)) > 2;
#10
SELECT m.full_name AS member,
       b.title,
       DATEDIFF(CURDATE(), l.due_date) AS days_late,
       DATEDIFF(CURDATE(), l.due_date) * 0.50 AS fine_amount
FROM loans l
         JOIN members m ON l.member_id = m.member_id
         JOIN copies c ON l.copy_id = c.copy_id
         JOIN books b ON c.book_id = b.book_id
WHERE l.return_date IS NULL AND CURDATE() > l.due_date;