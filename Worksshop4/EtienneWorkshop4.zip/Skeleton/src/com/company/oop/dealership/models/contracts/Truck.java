package com.company.oop.dealership.models.contracts;

public interface Truck {

    int getWeightCapacity();

    String getMake();
}
