package com.company.oop.dealership.models.contracts;

public interface Car {

    int getSeats();

    String getMake();
}
