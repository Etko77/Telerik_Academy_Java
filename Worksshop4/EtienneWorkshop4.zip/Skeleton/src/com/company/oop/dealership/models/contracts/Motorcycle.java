package com.company.oop.dealership.models.contracts;

public interface Motorcycle {

    String getCategory();

    String getMake();
}
