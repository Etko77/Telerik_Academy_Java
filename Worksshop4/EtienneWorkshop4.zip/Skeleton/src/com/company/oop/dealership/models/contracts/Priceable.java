package com.company.oop.dealership.models.contracts;

public interface Priceable {

    double getPrice();

}
