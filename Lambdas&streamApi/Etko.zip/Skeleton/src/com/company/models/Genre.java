package com.company.models;

public enum Genre {
    DRAMA, COMEDY, ACTION, HORROR, FANTASY
}
