package com.company.oop.cosmetics.commands;

public enum CommandType {
    CREATECATEGORY,
    CREATEPRODUCT,
    ADDPRODUCTTOCATEGORY,
    SHOWCATEGORY,
}
