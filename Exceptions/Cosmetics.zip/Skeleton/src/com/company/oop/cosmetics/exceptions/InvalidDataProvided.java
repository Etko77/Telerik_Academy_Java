package com.company.oop.cosmetics.exceptions;

public class InvalidDataProvided extends RuntimeException{
    public InvalidDataProvided(String message){
        super(message);
    }
}
