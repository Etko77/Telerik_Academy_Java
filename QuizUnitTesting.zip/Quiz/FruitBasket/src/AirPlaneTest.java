package test;


import org.junit.Test;

public class AirplaneTest {

    @Test
    public void testBoardPassengersSuccessfully() {
        /*Write your code here*/
    }

    @Test
    public void testDisembarkPassengersUnsuccessfully() {
        /*Write your code here*/
    }
}