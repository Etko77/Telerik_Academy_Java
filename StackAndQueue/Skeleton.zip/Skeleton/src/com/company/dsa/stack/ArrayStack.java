package com.company.dsa.stack;

import java.util.List;
import java.util.NoSuchElementException;

public class ArrayStack<E> implements Stack<E> {
    private E[] items;
    private static final int DEFAULT_CAPACITY = 10;
    private int top;

    public ArrayStack() {
        items = (E[]) new Object[DEFAULT_CAPACITY];
        top = 0;
    }
    public ArrayStack(E[] elements) {
        items = (E[]) new Object[elements.length];

        for(int i = 0; i < elements.length;i++){
            items[i] = elements[i];
        }
        top = elements.length;
    }

    @Override
    public void push(E element) {
        if (top == items.length) {
            resize();
        }
        items[top++] = element;
//        throw new UnsupportedOperationException();
    }
    private void resize() {
        int newCapacity = items.length * 2;
        E[] newArray = (E[]) new Object[newCapacity];

        for (int i = 0; i < top; i++) {
            newArray[i] = items[i];
        }
        items = newArray;
    }

    @Override
    public E pop() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        E element = items[--top];  // Move top down, then retrieve element
        items[top] = null;         // Avoid memory leak (help GC)
        return element;

    }

    @Override
    public E peek() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        E element = items[--top];
        return element;
    }

    @Override
    public int size() {
        return top;
    }

    @Override
    public boolean isEmpty() {
        return top == 0;
    }

}
