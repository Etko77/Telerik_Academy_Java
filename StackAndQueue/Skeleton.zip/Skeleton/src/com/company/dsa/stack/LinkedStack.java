package com.company.dsa.stack;

import com.company.dsa.Node;

import java.util.NoSuchElementException;

public class LinkedStack<E> implements Stack<E> {
    private Node<E> top;
    private int size;

    public LinkedStack(){
        this.size = 0;
        top = null;
    }


    @Override
    public void push(E element) {
        Node<E> newNode = new Node<>();
        newNode.data = element;
        newNode.next = top;  // newNode points to current top
        top = newNode;       // newNode becomes new top
        size++;
    }

    @Override
    public E pop() {
        if(isEmpty()){
            throw new NoSuchElementException();
        }
        E value = top.data;
        top = top.next;
        size--;
        return value;
    }

    @Override
    public E peek() {
        if(isEmpty()){
            throw new NoSuchElementException();
        }
        E value = top.data;
        return value;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }
}
